package de.hype.bbsentials.client.Commands;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import de.hype.bbsentials.api.ISimpleOption;
import de.hype.bbsentials.client.BBsentials;
import de.hype.bbsentials.communication.BBsentialConnection;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.command.CommandSource;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;
import static de.hype.bbsentials.client.BBsentials.bbserver;
import static de.hype.bbsentials.client.BBsentials.getConfig;

public class BBServerCommand extends Command {
    public BBServerCommand() {
        super("bbserver","sends a message to the BBsentials Server","BBsentials");
        System.out.println("Tried to configure bbserver command");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(argument("message", StringArgumentType.greedyString()).executes(context -> {
            String message = StringArgumentType.getString(context, "Message");
            if (message.equals("bb:reconnect")) {
                BBsentials.bbserver = new BBsentialConnection();
                bbserver.connect(getConfig().getBBServerURL(), 5000);
            }
            else {
                BBsentials.bbserver.sendMessage(message);
            }
            return SINGLE_SUCCESS;
        }));
    }
}